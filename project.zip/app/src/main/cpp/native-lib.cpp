// Minimal JNI glue: starts the embedded Node.js runtime (nodejs-mobile) in-process.
// node::Start may only be called ONCE per process.
#include <jni.h>
#include <android/log.h>
#include <pthread.h>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include "node.h"

#define TAG "ARCHI-NODE"

static int g_pipe[2];
static bool g_started = false;

static void* log_pump(void*) {
    char buf[2048];
    ssize_t n;
    while ((n = read(g_pipe[0], buf, sizeof(buf) - 1)) > 0) {
        if (buf[n - 1] == '\n') n--;
        buf[n] = 0;
        __android_log_write(ANDROID_LOG_INFO, TAG, buf);
    }
    return nullptr;
}

static void redirect_output() {
    setvbuf(stdout, nullptr, _IONBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
    if (pipe(g_pipe) != 0) return;
    dup2(g_pipe[1], STDOUT_FILENO);
    dup2(g_pipe[1], STDERR_FILENO);
    pthread_t t;
    pthread_create(&t, nullptr, log_pump, nullptr);
    pthread_detach(t);
}

extern "C" JNIEXPORT jint JNICALL
Java_ai_archi_poc_NodeBridge_startNodeWithArguments(JNIEnv* env, jobject, jobjectArray arguments) {
    if (g_started) return -2;
    g_started = true;
    redirect_output();

    jsize argc = env->GetArrayLength(arguments);
    size_t total = 0;
    for (jsize i = 0; i < argc; i++) {
        jstring s = (jstring) env->GetObjectArrayElement(arguments, i);
        const char* c = env->GetStringUTFChars(s, nullptr);
        total += strlen(c) + 1;
        env->ReleaseStringUTFChars(s, c);
    }
    char* buffer = (char*) calloc(total, sizeof(char));
    char** argv = (char**) calloc(argc, sizeof(char*));
    char* cur = buffer;
    for (jsize i = 0; i < argc; i++) {
        jstring s = (jstring) env->GetObjectArrayElement(arguments, i);
        const char* c = env->GetStringUTFChars(s, nullptr);
        size_t len = strlen(c);
        memcpy(cur, c, len);
        argv[i] = cur;
        cur += len + 1;
        env->ReleaseStringUTFChars(s, c);
    }
    return (jint) node::Start((int) argc, argv);
}
