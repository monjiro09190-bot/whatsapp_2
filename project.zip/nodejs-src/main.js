import fs from 'node:fs'
import WebSocket from 'ws'
import pino from 'pino'
import * as B from '@whiskeysockets/baileys'
import BAILEYS_VERSION from './version.js'

const makeWASocket = B.makeWASocket ?? B.default
const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } = B

const { ARCHI_PORT, ARCHI_TOKEN, ARCHI_AUTH_DIR } = process.env
const ws = new WebSocket(`ws://127.0.0.1:${ARCHI_PORT}/?token=${ARCHI_TOKEN}`)
const send = (o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)) }
const err = (where, e) => send({ t: 'error', where, msg: String(e?.message ?? e) })

process.on('uncaughtException', (e) => err('uncaught', e))
process.on('unhandledRejection', (e) => err('unhandled', e))

let sock = null
let pendingPhone = null
let qrReady = false
let codeRequested = false
const logger = pino({ level: 'silent' })

async function requestCode() {
  if (!sock || !pendingPhone || !qrReady || codeRequested || sock.authState.creds.registered) return
  codeRequested = true
  try {
    const code = await sock.requestPairingCode(pendingPhone)
    send({ t: 'pairing_code', code })
  } catch (e) {
    codeRequested = false
    err('requestPairingCode', e)
  }
}

async function startWA() {
  qrReady = false
  codeRequested = false
  const { state, saveCreds } = await useMultiFileAuthState(ARCHI_AUTH_DIR)
  let version
  try { ({ version } = await fetchLatestBaileysVersion()) } catch (e) { err('fetchLatestBaileysVersion', e) }
  sock = makeWASocket({
    version, auth: state, logger,
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false, markOnlineOnConnect: false, syncFullHistory: false,
  })
  const mine = sock
  sock.ev.on('creds.update', saveCreds)
  sock.ev.on('connection.update', async (u) => {
    if (mine !== sock) return
    const { connection, lastDisconnect, qr } = u
    if (qr) { qrReady = true; send({ t: 'qr_ready' }); await requestCode() }
    if (connection) send({ t: 'state', connection, registered: !!sock.authState.creds.registered })
    if (connection === 'open') send({ t: 'connected', jid: sock.user?.id })
    if (connection === 'close') {
      const status = lastDisconnect?.error?.output?.statusCode
      send({ t: 'closed', status })
      if (status === DisconnectReason.loggedOut) {
        fs.rmSync(ARCHI_AUTH_DIR, { recursive: true, force: true })
        setTimeout(startWA, 1000)
      } else {
        setTimeout(startWA, status === DisconnectReason.restartRequired ? 500 : 3000)
      }
    }
  })
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      if (!m.message || m.key.fromMe) continue
      const text = m.message.conversation || m.message.extendedTextMessage?.text || ''
      if (!text) continue
      const from = m.key.remoteJid
      send({ t: 'incoming', from, text })
      if (text.trim().toLowerCase() === '!ping') {
        try {
          const r = await sock.sendMessage(from, { text: 'pong from ARCHI.AI PoC' })
          send({ t: 'sent', id: r?.key?.id, to: from })
        } catch (e) { err('reply', e) }
      }
    }
  })
}

ws.on('open', () => {
  send({ t: 'hello', node: process.version, mobile: process.versions.mobile, arch: process.arch, baileys: BAILEYS_VERSION })
  startWA().catch((e) => err('startWA', e))
})
ws.on('message', async (d) => {
  let m
  try { m = JSON.parse(d.toString()) } catch { return }
  if (m.t === 'pair') {
    pendingPhone = String(m.phone ?? '').replace(/\D/g, '')
    if (!pendingPhone) return err('pair', 'empty phone')
    if (sock?.authState.creds.registered) return send({ t: 'info', msg: 'already registered; no code needed' })
    await requestCode()
  } else if (m.t === 'send') {
    try {
      const to = String(m.to).includes('@') ? m.to : String(m.to).replace(/\D/g, '') + '@s.whatsapp.net'
      const r = await sock.sendMessage(to, { text: String(m.text) })
      send({ t: 'sent', id: r?.key?.id, to })
    } catch (e) { err('send', e) }
  } else if (m.t === 'status') {
    send({ t: 'status', registered: !!sock?.authState.creds.registered, user: sock?.user?.id ?? null })
  }
})
ws.on('close', () => { /* Kotlin side gone: nothing to report to */ })
