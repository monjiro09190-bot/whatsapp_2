package ai.archi.poc

object NodeBridge {
    init { System.loadLibrary("archinode") }
    external fun startNodeWithArguments(args: Array<String>): Int
}
