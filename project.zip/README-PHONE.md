# ARCHI.AI Phase 1 PoC — status: SOURCE ONLY, NOTHING BUILT OR RUN YET

Upload from a phone browser (use "Desktop site"):
1. github.com -> New repository (private) -> create.
2. Add file -> Upload files -> upload project.zip (keep it zipped) -> Commit.
3. Add file -> Create new file -> name it  .github/workflows/build.yml  -> paste build.yml contents -> Commit.
4. Actions tab -> "Build ARCHI.AI PoC APK" -> Run workflow. Open the run to read logs.
5. When green, open the run -> Artifacts -> archi-poc-debug-apk -> download -> install (allow unknown sources).

Device test (use a SECONDARY number; Baileys is unofficial and can get numbers banned):
[ ] Start engine -> log shows hello with node version + baileys version
[ ] Enter secondary number -> Request pairing code -> 8-char code appears
[ ] WhatsApp > Linked devices > Link with phone number -> enter code
[ ] log shows state open / connected
[ ] Send test message -> 'sent' event, arrives on the other phone
[ ] Reply "!ping" from the other phone -> 'incoming' then pong comes back
[ ] Force-stop app, reopen, Start engine -> connects with NO new code (session restored)
