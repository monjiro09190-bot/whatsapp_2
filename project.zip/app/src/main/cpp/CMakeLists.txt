cmake_minimum_required(VERSION 3.22.1)
project("archinode")

add_library(node SHARED IMPORTED)
set_target_properties(node PROPERTIES
    IMPORTED_LOCATION ${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI}/libnode.so)

add_library(archinode SHARED native-lib.cpp)
target_include_directories(archinode PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../../../libnode/include/node)
target_link_libraries(archinode node log)
