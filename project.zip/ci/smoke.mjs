// Desktop-Node smoke test of the BUNDLE (not Android): proves bundle loads, Baileys initializes, bridge auth works.
// It never requests a pairing code, so no real number is contacted.
import { WebSocketServer } from '../nodejs-src/node_modules/ws/wrapper.mjs'
import { spawn } from 'node:child_process'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { once } from 'node:events'

const bundle = process.argv[2]
const token = 'smoke-' + Math.random().toString(16).slice(2)
const wss = new WebSocketServer({ host: '127.0.0.1', port: 0 })
await once(wss, 'listening')
const seen = new Set()
let badRejected = false
wss.on('connection', (s, req) => {
  if (!req.url.includes(token)) { badRejected = true; s.close(1008); return }
  s.on('message', (d) => {
    const m = JSON.parse(d.toString())
    console.log('node->', JSON.stringify(m))
    seen.add(m.t)
    if (m.t === 'state') seen.add('state:' + m.connection)
  })
})
const child = spawn(process.execPath, [bundle], {
  env: { ...process.env, ARCHI_PORT: String(wss.address().port), ARCHI_TOKEN: token,
         ARCHI_AUTH_DIR: mkdtempSync(join(tmpdir(), 'wa-')) },
  stdio: 'inherit',
})
setTimeout(() => {
  child.kill()
  const ok = seen.has('hello') && (seen.has('state:connecting') || seen.has('qr_ready'))
  console.log('SMOKE seen=', [...seen].join(','), 'RESULT=', ok ? 'PASS' : 'FAIL')
  process.exit(ok ? 0 : 1)
}, 30000)
