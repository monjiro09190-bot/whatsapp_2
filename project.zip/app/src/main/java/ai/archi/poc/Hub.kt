package ai.archi.poc

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.system.Os
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Process-wide hub: starts Node once, hosts the authenticated loopback WebSocket, relays events to the UI. */
object Hub {
    private val main = Handler(Looper.getMainLooper())
    private var started = false
    private var server: BridgeServer? = null
    @Volatile var client: WebSocket? = null
    @Volatile var listener: ((JSONObject) -> Unit)? = null
    private val history = ArrayList<JSONObject>()

    fun history(): List<JSONObject> = synchronized(history) { history.toList() }

    fun event(o: JSONObject) {
        synchronized(history) { history.add(o); if (history.size > 300) history.removeAt(0) }
        main.post { listener?.invoke(o) }
    }

    fun note(msg: String) = event(JSONObject().put("t", "app").put("msg", msg))

    fun onNode(raw: String) {
        try { event(JSONObject(raw)) } catch (e: Exception) { note("bad json from node") }
    }

    fun sendToNode(o: JSONObject): Boolean {
        val c = client ?: return false
        c.send(o.toString())
        return true
    }

    @Synchronized
    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val dir = File(app.filesDir, "nodejs").apply { mkdirs() }
        val script = File(dir, "bundle.mjs")
        app.assets.open("nodejs/bundle.mjs").use { i -> script.outputStream().use { o -> i.copyTo(o) } }

        // 256-bit random token, regenerated on every start, never written to disk or logs.
        val token = ByteArray(32).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        val srv = BridgeServer(token)
        srv.start()
        if (!srv.ready.await(5, TimeUnit.SECONDS)) { note("bridge failed to start"); started = false; return }
        server = srv

        Os.setenv("ARCHI_PORT", srv.port.toString(), true)
        Os.setenv("ARCHI_TOKEN", token, true)
        Os.setenv("ARCHI_AUTH_DIR", File(app.filesDir, "wa_auth").absolutePath, true)
        Os.setenv("HOME", app.filesDir.absolutePath, true)
        Os.setenv("TMPDIR", app.cacheDir.absolutePath, true)

        Thread(null, {
            note("starting node")
            val rc = NodeBridge.startNodeWithArguments(arrayOf("node", script.absolutePath))
            note("node exited rc=$rc")
        }, "node-main", 4L * 1024 * 1024).start()
    }
}

class BridgeServer(private val token: String) :
    WebSocketServer(InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0)) {
    val ready = CountDownLatch(1)
    override fun onStart() { ready.countDown() }
    override fun onOpen(conn: WebSocket, hs: ClientHandshake) {
        val presented = hs.resourceDescriptor.substringAfter("token=", "")
        val ok = MessageDigest.isEqual(presented.toByteArray(), token.toByteArray())
        if (!ok || Hub.client != null) { conn.close(1008, "unauthorized"); return }
        Hub.client = conn
        Hub.note("node connected to bridge")
    }
    override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
        if (Hub.client === conn) Hub.client = null
    }
    override fun onMessage(conn: WebSocket, message: String) {
        if (conn === Hub.client) Hub.onNode(message)
    }
    override fun onError(conn: WebSocket?, ex: Exception) {
        Hub.note("bridge error: ${ex.javaClass.simpleName}")
    }
}
