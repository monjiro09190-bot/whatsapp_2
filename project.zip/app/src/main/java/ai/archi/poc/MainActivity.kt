package ai.archi.poc

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var code: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { onClick() }
    }
    private fun edit(hintText: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        hint = hintText; inputType = type
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val phone = edit("Secondary WhatsApp number, digits only, with country code", InputType.TYPE_CLASS_PHONE)
        val to = edit("Send test message to (number, digits only)", InputType.TYPE_CLASS_PHONE)
        val msg = edit("Test message text")
        code = TextView(this).apply { textSize = 34f; gravity = Gravity.CENTER; text = "— — — —"; setTextIsSelectable(true) }
        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
            addView(TextView(context).apply { text = "ARCHI.AI — Phase 1 PoC"; textSize = 20f })
            addView(btn("1. Start engine (Node + Baileys)") { startEngine() })
            addView(phone)
            addView(btn("2. Request pairing code") {
                val ok = Hub.sendToNode(JSONObject().put("t", "pair").put("phone", phone.text.toString()))
                if (!ok) Hub.note("engine not connected yet; press Start first and wait for 'node connected'")
            })
            addView(code)
            addView(btn("Copy code") {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("pairing", code.text))
            })
            addView(to); addView(msg)
            addView(btn("3. Send test message") {
                Hub.sendToNode(JSONObject().put("t", "send").put("to", to.text.toString()).put("text", msg.text.toString()))
            })
            addView(btn("Status") { Hub.sendToNode(JSONObject().put("t", "status")) })
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
    }

    private fun startEngine() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, BotService::class.java))
    }

    private fun render(o: JSONObject) {
        if (o.optString("t") == "pairing_code") code.text = o.optString("code")
        logView.append(o.toString() + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onResume() {
        super.onResume()
        logView.text = ""
        Hub.history().forEach { render(it) }
        Hub.listener = { render(it) }
    }

    override fun onPause() { super.onPause(); Hub.listener = null }
}
